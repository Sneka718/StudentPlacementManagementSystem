package com.stackly.service;
import java.util.List;
import com.stackly.dto.ApplicationDTO;
import com.stackly.model.JobApplication.ApplicationStatus;

public interface ApplicationService {

    ApplicationDTO applyForJob(ApplicationDTO applicationDTO);

    ApplicationDTO getApplicationById(Long id);

    List<ApplicationDTO> getApplicationsByStudent(Long studentId);

    List<ApplicationDTO> getApplicationsByJob(Long jobId);

    ApplicationDTO updateApplicationStatus(
            Long id, ApplicationStatus status);

    void withdrawApplication(Long id);
}