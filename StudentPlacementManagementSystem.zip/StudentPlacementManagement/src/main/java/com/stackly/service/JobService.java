package com.stackly.service; 
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.stackly.dto.JobDTO;
import com.stackly.dto.StudentDTO;

public interface JobService {

    JobDTO createJob(JobDTO jobDTO);

    Page<StudentDTO> getAllJobs(Pageable pageable);
    
    JobDTO getJobById(Long id);

    List<JobDTO> getAllJobs();

    JobDTO updateJob(Long id, JobDTO jobDTO);

    void deleteJob(Long id);

    List<JobDTO> getEligibleJobs(Double cgpa);
}