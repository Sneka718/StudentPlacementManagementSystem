package com.stackly.service;

import java.util.List;

import com.stackly.model.Company;

public interface CompanyService {

    Company createCompany(Company company);

    Company getCompanyById(Long id);

    List<Company> getAllCompanies();

    Company updateCompany(Long id, Company company);

    void deleteCompany(Long id);
}