package com.stackly.scheduler;
import java.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.stackly.repository.JobRepository;


@Component
public class JobDeadlineScheduler {

    private static final Logger logger =
            LoggerFactory.getLogger(JobDeadlineScheduler.class);

    private final JobRepository jobRepository;

    public JobDeadlineScheduler(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    // Runs every day at midnight.
    @Scheduled(cron = "0 0 0 * * *")
    public void checkExpiredJobs() {
        long expiredJobs = jobRepository
                .findAll()
                .stream()
                .filter(job -> job.getDeadline() != null)
                .filter(job -> job.getDeadline().isBefore(LocalDate.now()))
                .count();

        logger.info("Daily deadline check completed. Expired jobs: {}",
                expiredJobs);
    }
}