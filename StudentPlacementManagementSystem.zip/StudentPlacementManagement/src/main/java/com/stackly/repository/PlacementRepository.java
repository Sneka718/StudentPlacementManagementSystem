package com.stackly.repository;
import com.stackly.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlacementRepository
        extends JpaRepository<Placement, Long> {

    Optional<Placement> findByStudentId(Long studentId);

    List<Placement> findByCompanyId(Long companyId);

    List<Placement> findByPackageLpaGreaterThanEqual(
            Double packageLpa);

    boolean existsByStudentId(Long studentId);
}