package com.stackly.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackly.model.Student;

import java.util.Optional;
import java.util.List;

@Repository
public interface StudentRepository
        extends JpaRepository<Student, Long> {

    Optional<Student> findByEmail(String email);

    List<Student> findByDepartment(String department);

    List<Student> findByCgpaGreaterThanEqual(Double cgpa);

    boolean existsByEmail(String email);
}