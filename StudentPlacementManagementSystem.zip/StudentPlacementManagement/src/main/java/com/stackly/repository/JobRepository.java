package com.stackly.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.stackly.model.Job;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface JobRepository
        extends JpaRepository<Job, Long> {

    List<Job> findByTitleContainingIgnoreCase(String title);

    List<Job> findByCompanyId(Long companyId);

    List<Job> findByMinimumCgpaLessThanEqual(
            Double cgpa);

    List<Job> findByDeadlineGreaterThanEqual(
            LocalDate date);

    @Query("SELECT j FROM Job j WHERE j.minimumCgpa <= :cgpa")
    List<Job> findEligibleJobs(
            @Param("cgpa") Double cgpa);
}