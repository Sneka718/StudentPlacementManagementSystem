package com.stackly.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.stackly.model.JobApplication;
import com.stackly.model.JobApplication.ApplicationStatus;

import java.util.List;

@Repository
public interface JobApplicationRepository
        extends JpaRepository<JobApplication, Long> {

    List<JobApplication> findByStudentId(Long studentId);

    List<JobApplication> findByJobId(Long jobId);

    List<JobApplication> findByStatus(
            ApplicationStatus status);

    boolean existsByStudentIdAndJobId(
            Long studentId, Long jobId);

    long countByStatus(ApplicationStatus status);
}