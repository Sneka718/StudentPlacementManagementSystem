package com.stackly.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackly.model.Company;

import java.util.Optional;
import java.util.List;

@Repository
public interface CompanyRepository
        extends JpaRepository<Company, Long> {

    Optional<Company> findByEmail(String email);

    List<Company> findByIndustry(String industry);

    List<Company> findByLocationContainingIgnoreCase(
            String location);

    boolean existsByEmail(String email);
}