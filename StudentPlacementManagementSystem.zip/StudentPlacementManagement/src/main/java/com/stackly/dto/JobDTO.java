package com.stackly.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.LocalDate;

public class JobDTO {

    private Long id;

    @NotBlank(message = "Job title is required")
    private String title;

    private String description;
    private String location;
    private String jobType;

    @NotNull(message = "Minimum CGPA is required")
    @DecimalMin("0.0")
    @DecimalMax("10.0")
    private Double minimumCgpa;

    @NotNull(message = "Package is required")
    @PositiveOrZero
    private Double packageLpa;

    private LocalDate deadline;

    @NotNull(message = "Company ID is required")
    private Long companyId;

    private String companyName;

    public JobDTO() {
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() { return location; }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getJobType() { return jobType; }
    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Double getMinimumCgpa() { return minimumCgpa; }
    public void setMinimumCgpa(Double minimumCgpa) {
        this.minimumCgpa = minimumCgpa;
    }

    public Double getPackageLpa() { return packageLpa; }
    public void setPackageLpa(Double packageLpa) {
        this.packageLpa = packageLpa;
    }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public Long getCompanyId() { return companyId; }
    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}