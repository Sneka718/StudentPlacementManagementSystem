package com.stackly.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.stackly.audit.AuditableEntity;

@Entity
@Table(name = "companies")
public class Company  extends AuditableEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Company name is required")
    @Column(nullable = false)
    private String name;

    @NotBlank(message = "Email is required")
    @Email
    @Column(nullable = false, unique = true)
    private String email;

    private String phone;
    private String location;
    private String industry;
    private String website;

    @OneToMany(mappedBy = "company",
               cascade = CascadeType.ALL)
    private List<Job> jobs = new ArrayList<>();

    public Company() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getLocation() { return location; }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getIndustry() { return industry; }
    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getWebsite() { return website; }
    public void setWebsite(String website) {
        this.website = website;
    }

    public List<Job> getJobs() { return jobs; }
    public void setJobs(List<Job> jobs) { this.jobs = jobs; }
}