package com.stackly.serviceimpl;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.stackly.dto.StudentDTO;
import com.stackly.model.Student;
import com.stackly.repository.StudentRepository;
import com.stackly.service.StudentService;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    private StudentDTO toDTO(Student s) {
        StudentDTO d = new StudentDTO();
        d.setId(s.getId());
        d.setName(s.getName());
        d.setEmail(s.getEmail());
        d.setPhone(s.getPhone());
        d.setDepartment(s.getDepartment());
        d.setCgpa(s.getCgpa());
        d.setGraduationYear(s.getGraduationYear());
        return d;
    }

    private Student toEntity(StudentDTO d) {
        Student s = new Student();
        s.setName(d.getName());
        s.setEmail(d.getEmail());
        s.setPhone(d.getPhone());
        s.setDepartment(d.getDepartment());
        s.setCgpa(d.getCgpa());
        s.setGraduationYear(d.getGraduationYear());
        return s;
    }

    @Override
    public StudentDTO createStudent(StudentDTO dto) {
        if (studentRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already registered");
        }

        Student s = toEntity(dto);
        return toDTO(studentRepository.save(s));
    }

    @Override
    @Transactional(readOnly = true)
    public StudentDTO getStudentById(Long id) {
        return studentRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() ->
                    new RuntimeException("Student not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll()
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Override
    public Page<StudentDTO> getAllStudents(Pageable pageable) {
        return studentRepository.findAll(pageable)
                .map(student -> {
                    StudentDTO dto = new StudentDTO();
                    dto.setId(student.getId());
                    dto.setName(student.getName());
                    dto.setEmail(student.getEmail());
                    dto.setPhone(student.getPhone());
                    dto.setDepartment(student.getDepartment());
                    dto.setCgpa(student.getCgpa());
                    dto.setGraduationYear(student.getGraduationYear());
                    return dto;
                });
    }
    
    @Override
    public StudentDTO updateStudent(Long id, StudentDTO dto) {
        Student s = studentRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Student not found: " + id));

        studentRepository.findByEmail(dto.getEmail())
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> {
                    throw new IllegalArgumentException("Email already registered");
                });

        s.setName(dto.getName());
        s.setEmail(dto.getEmail());
        s.setPhone(dto.getPhone());
        s.setDepartment(dto.getDepartment());
        s.setCgpa(dto.getCgpa());
        s.setGraduationYear(dto.getGraduationYear());

        return toDTO(studentRepository.save(s));
    }

    @Override
    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new RuntimeException("Student not found: " + id);
        }
        studentRepository.deleteById(id);
    }
}