package com.stackly.serviceimpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.stackly.model.Company;
import com.stackly.repository.CompanyRepository;
import com.stackly.service.CompanyService;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;

    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public Company createCompany(Company company) {
        if (companyRepository.existsByEmail(company.getEmail())) {
            throw new IllegalArgumentException("Company email already exists");
        }
        return companyRepository.save(company);
    }

    @Override
    @Transactional(readOnly = true)
    public Company getCompanyById(Long id) {
        return companyRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Company not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    @Override
    public Company updateCompany(Long id, Company details) {
        Company company = getCompanyById(id);

        companyRepository.findByEmail(details.getEmail())
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> {
                    throw new IllegalArgumentException("Company email already exists");
                });

        company.setName(details.getName());
        company.setEmail(details.getEmail());
        company.setPhone(details.getPhone());
        company.setLocation(details.getLocation());
        company.setIndustry(details.getIndustry());
        company.setWebsite(details.getWebsite());
        return companyRepository.save(company);
    }

    @Override
    public void deleteCompany(Long id) {
        if (!companyRepository.existsById(id)) {
            throw new RuntimeException("Company not found: " + id);
        }
        companyRepository.deleteById(id);
    }
}