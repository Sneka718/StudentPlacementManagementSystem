package com.stackly.serviceimpl;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.stackly.dto.JobDTO;
import com.stackly.model.Company;
import com.stackly.model.Job;
import com.stackly.repository.CompanyRepository;
import com.stackly.repository.JobRepository;
import com.stackly.service.JobService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;
    private final CompanyRepository companyRepository;

    public JobServiceImpl(JobRepository jobRepository,
                          CompanyRepository companyRepository) {
        this.jobRepository = jobRepository;
        this.companyRepository = companyRepository;
    }

    @Override
    public Page getAllJobs(Pageable pageable) {
        return jobRepository.findAll(pageable)
                .map(job -> {
                    JobDTO dto = new JobDTO();
                    dto.setId(job.getId());
                    dto.setTitle(job.getTitle());
                    dto.setDescription(job.getDescription());
                    dto.setLocation(job.getLocation());
                    dto.setJobType(job.getJobType());
                    dto.setMinimumCgpa(job.getMinimumCgpa());
                    dto.setPackageLpa(job.getPackageLpa());
                    dto.setDeadline(job.getDeadline());

                    if (job.getCompany() != null) {
                        dto.setCompanyId(job.getCompany().getId());
                        dto.setCompanyName(job.getCompany().getName());
                    }

                    return dto;
                });
    }
    
    private JobDTO toDTO(Job j) {
        JobDTO d = new JobDTO();
        d.setId(j.getId());
        d.setTitle(j.getTitle());
        d.setDescription(j.getDescription());
        d.setLocation(j.getLocation());
        d.setJobType(j.getJobType());
        d.setMinimumCgpa(j.getMinimumCgpa());
        d.setPackageLpa(j.getPackageLpa());
        d.setDeadline(j.getDeadline());
        d.setCompanyId(j.getCompany().getId());
        d.setCompanyName(j.getCompany().getName());
        return d;
    }

    private Job toEntity(JobDTO d, Company company) {
        Job j = new Job();
        j.setTitle(d.getTitle());
        j.setDescription(d.getDescription());
        j.setLocation(d.getLocation());
        j.setJobType(d.getJobType());
        j.setMinimumCgpa(d.getMinimumCgpa());
        j.setPackageLpa(d.getPackageLpa());
        j.setDeadline(d.getDeadline());
        j.setCompany(company);
        return j;
    }

    @Override
    public JobDTO createJob(JobDTO dto) {
        Company company = companyRepository.findById(dto.getCompanyId())
                .orElseThrow(() ->
                    new RuntimeException("Company not found"));

        Job job = toEntity(dto, company);
       
        return toDTO(jobRepository.save(job));
    }

    @Override
    @Transactional(readOnly = true)
    public JobDTO getJobById(Long id) {
        return jobRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() ->
                    new RuntimeException("Job not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobDTO> getAllJobs() {
        return jobRepository.findAll()
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Override
    public JobDTO updateJob(Long id, JobDTO dto) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Job not found: " + id));

        Company company = companyRepository.findById(dto.getCompanyId())
                .orElseThrow(() ->
                    new RuntimeException("Company not found"));

        job.setTitle(dto.getTitle());
        job.setDescription(dto.getDescription());
        job.setLocation(dto.getLocation());
        job.setJobType(dto.getJobType());
        job.setMinimumCgpa(dto.getMinimumCgpa());
        job.setPackageLpa(dto.getPackageLpa());
        job.setDeadline(dto.getDeadline());
        job.setCompany(company);

        return toDTO(jobRepository.save(job));
    }

    @Override
    public void deleteJob(Long id) {
        if (!jobRepository.existsById(id)) {
            throw new RuntimeException("Job not found: " + id);
        }
        jobRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobDTO> getEligibleJobs(Double cgpa) {
        return jobRepository.findEligibleJobs(cgpa)
                .stream()
                .filter(j -> j.getDeadline() == null
                        || !j.getDeadline().isBefore(LocalDate.now()))
                .map(this::toDTO)
                .toList();
    }
}