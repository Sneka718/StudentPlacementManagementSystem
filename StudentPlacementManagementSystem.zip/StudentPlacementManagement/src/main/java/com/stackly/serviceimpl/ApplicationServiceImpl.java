package com.stackly.serviceimpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.stackly.dto.ApplicationDTO;
import com.stackly.model.Job;
import com.stackly.model.JobApplication;
import com.stackly.model.JobApplication.ApplicationStatus;
import com.stackly.model.Student;
import com.stackly.repository.JobApplicationRepository;
import com.stackly.repository.JobRepository;
import com.stackly.repository.StudentRepository;
import com.stackly.service.ApplicationService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class ApplicationServiceImpl implements ApplicationService {

    private final JobApplicationRepository applicationRepository;
    private final StudentRepository studentRepository;
    private final JobRepository jobRepository;

    public ApplicationServiceImpl(
            JobApplicationRepository applicationRepository,
            StudentRepository studentRepository,
            JobRepository jobRepository) {
        this.applicationRepository = applicationRepository;
        this.studentRepository = studentRepository;
        this.jobRepository = jobRepository;
    }

    private ApplicationDTO toDTO(JobApplication a) {
        ApplicationDTO d = new ApplicationDTO();
        d.setId(a.getId());
        d.setStudentId(a.getStudent().getId());
        d.setStudentName(a.getStudent().getName());
        d.setJobId(a.getJob().getId());
        d.setJobTitle(a.getJob().getTitle());
        d.setCompanyName(a.getJob().getCompany().getName());
        d.setStatus(a.getStatus());
        d.setAppliedDate(a.getAppliedDate());
        return d;
    }

    @Override
    public ApplicationDTO applyForJob(ApplicationDTO dto) {
        Student student = studentRepository.findById(dto.getStudentId())
                .orElseThrow(() ->
                    new RuntimeException("Student not found"));

        Job job = jobRepository.findById(dto.getJobId())
                .orElseThrow(() ->
                    new RuntimeException("Job not found"));

        if (job.getDeadline() != null
                && job.getDeadline().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Application deadline has passed");
        }

        if (student.getCgpa() < job.getMinimumCgpa()) {
            throw new IllegalArgumentException("Student does not meet CGPA criteria");
        }

        if (applicationRepository.existsByStudentIdAndJobId(
                student.getId(), job.getId())) {
            throw new IllegalArgumentException("Already applied for this job");
        }

        JobApplication application = new JobApplication();
        application.setStudent(student);
        application.setJob(job);
        application.setStatus(ApplicationStatus.APPLIED);
        application.setAppliedDate(LocalDateTime.now());

        return toDTO(applicationRepository.save(application));
    }

    @Override
    @Transactional(readOnly = true)
    public ApplicationDTO getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .map(this::toDTO)
                .orElseThrow(() ->
                    new RuntimeException("Application not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDTO> getApplicationsByStudent(Long studentId) {
        return applicationRepository.findByStudentId(studentId)
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDTO> getApplicationsByJob(Long jobId) {
        return applicationRepository.findByJobId(jobId)
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @Override
    public ApplicationDTO updateApplicationStatus(
            Long id, ApplicationStatus status) {
        JobApplication application = applicationRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Application not found: " + id));

        application.setStatus(status);
        return toDTO(applicationRepository.save(application));
    }

    @Override
    public void withdrawApplication(Long id) {
        JobApplication application = applicationRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Application not found: " + id));

        if (application.getStatus() == ApplicationStatus.SELECTED
                || application.getStatus() == ApplicationStatus.REJECTED) {
            throw new IllegalArgumentException(
                    "Cannot withdraw a finalized application");
        }

        application.setStatus(ApplicationStatus.WITHDRAWN);
        applicationRepository.save(application);
    }
}