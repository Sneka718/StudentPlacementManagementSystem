package com.stackly.controller;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stackly.dto.ApplicationDTO;
import com.stackly.model.JobApplication.ApplicationStatus;
import com.stackly.service.ApplicationService;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    private final ApplicationService applicationService;

    public ApplicationController(
            ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping
    public ResponseEntity<ApplicationDTO> applyForJob(
            @Valid @RequestBody ApplicationDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(applicationService.applyForJob(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApplicationDTO> getApplication(
            @PathVariable Long id) {
        return ResponseEntity.ok(
                applicationService.getApplicationById(id));
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<ApplicationDTO>> getByStudent(
            @PathVariable Long studentId) {
        return ResponseEntity.ok(
                applicationService.getApplicationsByStudent(studentId));
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<List<ApplicationDTO>> getByJob(
            @PathVariable Long jobId) {
        return ResponseEntity.ok(
                applicationService.getApplicationsByJob(jobId));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApplicationDTO> updateStatus(
            @PathVariable Long id,
            @RequestParam ApplicationStatus status) {
        return ResponseEntity.ok(
                applicationService.updateApplicationStatus(id, status));
    }

    @PatchMapping("/{id}/withdraw")
    public ResponseEntity<Void> withdrawApplication(
            @PathVariable Long id) {
        applicationService.withdrawApplication(id);
        return ResponseEntity.noContent().build();
    }
}